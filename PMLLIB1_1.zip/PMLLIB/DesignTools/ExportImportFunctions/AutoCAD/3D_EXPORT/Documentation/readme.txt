Dear Mr. Ritter,
I am sending you improved version of the programs. I eliminated a problem
 which was caused by conversion of large numbers into exponential format 
while exporting from PDMS.
Note: In file importPDMS.lsp line number 5, change the path, please. Regards Ladislav Roth
