﻿IMPORT '\\srv-aveva-01v\AVEVA\ADDONS\PMLLIB\AVEVA-MACRO\PMLLIB\common\SaveArrayToExcel\SaveArrayToExcel'
USING NAMESPACE 'SaveArrayToExcel'
!em = object FileWriter()

-- Задаём имя для сохранения файл
!em.CreateFile('D:\FileName.xlsx')

-- Создаём одномерный массив
!ar = object ARRAY()
!ar.Append('Text 1')
!ar.Append('Text 2')
!ar.Append('Text 3')

-- Запись строки в файл Excel
!em.WriteExcelRow(!ar)

-- Или создаём сразу двумерный массив
!arr = object ARRAY()
!arr.Append(!ar)
!arr.Append(!ar)
!arr.Append(!ar)
!arr.Append(!ar)
!arr.Append(!ar)

-- Добавляем в файл двумерный массив, как таблицу
!em.WriteExcelTable(!arr)

-- Можно комбинировать запись таблицы и строки в любой последовательности

-- Сохраняем и закрываем Excel файл
!em.SaveAndClose()

-- После сохранения файла, можно начать писать в новый файл
-- задав новое имя для Excel файла, методом CreateFile